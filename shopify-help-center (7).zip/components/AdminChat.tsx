
// This file is no longer used. See AdminChatPage.tsx for the new full-screen implementation.
export {};
