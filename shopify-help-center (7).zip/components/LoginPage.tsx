
import React, { useState, useEffect } from 'react';

interface LoginPageProps {
  onLogin: (email: string, ticketId: string) => void;
  onAdminLogin: () => void;
}

type AuthState = 'input' | 'verifying' | 'success';

// Master Ticket ID required for all merchants
const AUTHORIZED_TICKET_ID = 'HEP-25273';

const LoginPage: React.FC<LoginPageProps> = ({ onLogin, onAdminLogin }) => {
  const [email, setEmail] = useState('');
  const [ticketId, setTicketId] = useState('');
  const [authState, setAuthState] = useState<AuthState>('input');
  const [error, setError] = useState<string | null>(null);
  const [adminTapCount, setAdminTapCount] = useState(0);

  useEffect(() => {
    if (adminTapCount > 0) {
      const timer = setTimeout(() => {
        setAdminTapCount(0);
      }, 1500); 
      return () => clearTimeout(timer);
    }
  }, [adminTapCount]);

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const submittedEmail = email.trim().toLowerCase();
    const submittedTicket = ticketId.trim().toUpperCase();

    // 1. BASIC IDENTITY VALIDATION
    if (!validateEmail(submittedEmail)) {
      setError('Please enter a valid email address.');
      return;
    }

    // 2. TICKET CLEARANCE VERIFICATION (Master Key Check)
    if (submittedTicket !== AUTHORIZED_TICKET_ID) {
      setError('Invalid Ticket Reference: The provided Ticket ID does not match an active support session.');
      return;
    }
    
    setAuthState('verifying');
    
    // Simulate a secure backend verification handshake
    setTimeout(() => {
      setAuthState('success');
      setTimeout(() => onLogin(submittedEmail, submittedTicket), 800);
    }, 1800);
  };

  const handleSecretTap = () => {
    const newCount = adminTapCount + 1;
    if (newCount >= 3) {
      onAdminLogin();
      setAdminTapCount(0);
    } else {
      setAdminTapCount(newCount);
    }
  };

  return (
    <div className="min-h-screen bg-[#f6f6f7] flex flex-col items-center justify-center px-4 py-12 relative overflow-hidden">
      
      {/* VERIFYING OVERLAY */}
      {(authState === 'verifying' || authState === 'success') && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-white animate-in fade-in duration-500">
          <div className="text-center">
            {authState === 'verifying' ? (
              <div className="flex flex-col items-center gap-6">
                <div className="relative">
                  <div className="w-16 h-16 border-4 border-gray-100 rounded-full"></div>
                  <div className="w-16 h-16 border-4 border-[#008060] border-t-transparent rounded-full animate-spin absolute top-0"></div>
                </div>
                <div className="space-y-2">
                  <h2 className="text-xl font-bold text-[#202223]">Authorizing Session...</h2>
                  <p className="text-sm text-[#6d7175]">Verifying Ticket #{ticketId} Clearance</p>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-6 animate-in zoom-in duration-300">
                <div className="w-16 h-16 bg-[#008060] rounded-full flex items-center justify-center text-white shadow-xl">
                  <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h2 className="text-2xl font-bold text-[#202223]">Handshake Successful</h2>
              </div>
            )}
          </div>
        </div>
      )}

      <div className="w-full max-w-[440px] z-10">
        <div className="flex flex-col items-center mb-8">
          <div className="flex items-center gap-3 mb-2">
            <img 
              src="https://logo.svgcdn.com/logos/shopify.png" 
              alt="Shopify" 
              className="h-10 w-auto object-contain"
            />
          </div>
          <h1 className="text-2xl font-black text-[#202223] mt-4 tracking-tight">Merchant Portal</h1>
          <p className="text-[#6d7175] mt-2 text-center text-sm px-4 font-medium italic">
            Single-session encrypted connection required.
          </p>
        </div>

        <div className="bg-white rounded-[32px] shadow-[0_20px_60px_rgba(0,0,0,0.05)] border border-gray-100 p-10 relative">
          <div className="absolute top-0 right-10 -translate-y-1/2">
            <span className="px-4 py-1.5 bg-[#202223] text-white text-[10px] font-black uppercase tracking-[0.2em] rounded-full shadow-lg">
              Secure Entrance
            </span>
          </div>

          <form onSubmit={handleManualSubmit} className="space-y-6">
            <div>
              <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2 px-1">Merchant Gmail</label>
              <div className="relative group">
                <input 
                  type="email" 
                  value={email}
                  autoFocus
                  required
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (error) setError(null);
                  }}
                  className={`w-full px-5 py-4 bg-[#f6f6f7] border-2 ${error && !email ? 'border-red-500' : 'border-transparent'} rounded-2xl focus:outline-none focus:bg-white focus:border-[#008060] transition-all text-[16px] font-medium`}
                  placeholder="yourname@gmail.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2 px-1">Ticket Reference ID</label>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none text-gray-400">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                </div>
                <input 
                  type="text" 
                  value={ticketId}
                  required
                  onChange={(e) => {
                    setTicketId(e.target.value);
                    if (error) setError(null);
                  }}
                  className={`w-full pl-12 pr-5 py-4 bg-[#f6f6f7] border-2 ${error && !ticketId ? 'border-red-500' : 'border-transparent'} rounded-2xl focus:outline-none focus:bg-white focus:border-[#008060] transition-all text-[16px] font-mono tracking-wider`}
                  placeholder="TIC-12345"
                />
              </div>
            </div>
            
            {error && (
              <div className="bg-red-50 border border-red-100 p-4 rounded-2xl flex items-start gap-4 animate-in shake duration-300">
                <div className="w-6 h-6 bg-red-100 rounded-full flex items-center justify-center shrink-0 mt-0.5">
                  <svg className="w-4 h-4 text-red-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                  </svg>
                </div>
                <p className="text-xs text-red-900 font-bold leading-tight">{error}</p>
              </div>
            )}

            <button 
              type="submit"
              className="w-full bg-[#202223] text-white py-4.5 rounded-[20px] font-black text-lg hover:bg-black transition-all shadow-[0_10px_20px_rgba(0,0,0,0.1)] active:scale-[0.98]"
            >
              Verify Clearance
            </button>
          </form>

          <div className="bg-[#f9fafb] border border-gray-100 p-5 rounded-2xl mt-8">
            <div className="flex gap-4">
              <div className="w-10 h-10 bg-white rounded-xl shadow-sm border border-gray-50 flex items-center justify-center shrink-0">
                <svg className="w-5 h-5 text-[#008060]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div>
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Support Protocol</p>
                <p className="text-[11px] text-gray-500 leading-relaxed font-medium">
                  Merchants must provide their registered Gmail and the master Ticket ID found in their invitation email.
                </p>
              </div>
            </div>
          </div>
          
          <button 
            onClick={handleSecretTap}
            className="absolute bottom-4 right-4 text-gray-100 hover:text-gray-200 transition-all p-2 group"
            title="Terminal Access"
          >
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
            </svg>
          </button>
        </div>

        <div className="mt-8 text-center">
          <p className="text-[11px] text-gray-400 font-bold uppercase tracking-widest">
            Session Encrypted • ID: SHP-AUTH-01
          </p>
        </div>
      </div>

      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-green-50 rounded-full -mr-80 -mt-80 blur-[120px] opacity-40 pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-green-50 rounded-full -ml-80 -mb-80 blur-[120px] opacity-40 pointer-events-none"></div>
    </div>
  );
};

export default LoginPage;
