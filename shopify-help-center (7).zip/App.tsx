
import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import CategoryGrid from './components/CategoryGrid';
import FAQAccordion from './components/FAQAccordion';
import ArticleView from './components/ArticleView';
import LoginPage from './components/LoginPage';
import AdminChatPage from './components/AdminChatPage';
import AdminDashboard from './components/AdminDashboard';
import AdminLoginPage from './components/AdminLoginPage';
import { ViewState, AdminUser } from './types';
import { getSmartSupportResponse } from './services/geminiService';
import { authService } from './services/authService';
import { supabase, supabaseAnonKey, getEnv, isSupabaseConfigured } from './lib/supabase';

const App: React.FC = () => {
  const [view, setView] = useState<ViewState>('login');
  const [userEmail, setUserEmail] = useState<string>('');
  const [targetUserEmail, setTargetUserEmail] = useState<string>(''); 
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null);
  const [selectedArticleId, setSelectedArticleId] = useState<string | null>(null);
  const [searchResult, setSearchResult] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isSearching, setIsSearching] = useState(false);
  const [isDbReady, setIsDbReady] = useState(false);
  const [isDemoMode, setIsDemoMode] = useState(false);
  const [isChatAdminView, setIsChatAdminView] = useState(false);

  const hasApiKey = !!getEnv('API_KEY');
  const hasSupabaseKey = isSupabaseConfigured;

  useEffect(() => {
    const initApp = async () => {
      try {
        const savedEmail = localStorage.getItem('shopify_merchant_email');
        if (savedEmail) {
          setUserEmail(savedEmail);
          setView('home');
        }

        if (hasSupabaseKey) {
          const { data: { session } } = await supabase.auth.getSession();
          if (session?.user) {
            const user = await authService.getCurrentUser();
            if (user) {
              setAdminUser(user);
              setView('admin_dashboard');
            }
          }
        }
        setIsDbReady(true);
      } catch (err) {
        setIsDbReady(true);
      }
    };
    initApp();
  }, [hasSupabaseKey]);

  const handleSearch = async (query: string) => {
    setIsSearching(true);
    setSearchQuery(query);
    setSearchResult(null);
    const resultsAnchor = document.getElementById('search-results');
    if (resultsAnchor) { resultsAnchor.scrollIntoView({ behavior: 'smooth' }); }
    const result = await getSmartSupportResponse(query);
    setSearchResult(result);
    setIsSearching(false);
    setView('home');
  };

  const navigateToArticle = (id: string) => {
    setSelectedArticleId(id);
    setView('article');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateToHome = () => {
    setView('home');
    setSelectedArticleId(null);
    setSearchResult(null);
    setSearchQuery('');
    setIsChatAdminView(false);
  };

  const handleLoginSuccess = async (email: string, ticketId: string) => {
    const cleanEmail = email.trim().toLowerCase();
    setUserEmail(cleanEmail);
    localStorage.setItem('shopify_merchant_email', cleanEmail);
    
    const initMessage = `--- Merchant Session Initialized: Ticket #${ticketId} ---`;

    // 1. Production Database Sync
    if (hasSupabaseKey) {
      await supabase.from('chat_messages').insert({
        text: initMessage,
        sender: 'user',
        type: 'text',
        user_email: cleanEmail
      });
    }

    // 2. Demo Sandbox Sync (LocalStorage)
    // We append the session init to the user's specific local chat log
    const storageKey = `shopify_chat_${cleanEmail}`;
    const localMsgs = JSON.parse(localStorage.getItem(storageKey) || '[]');
    localMsgs.push({
      id: 'session-init-' + Date.now(),
      text: initMessage,
      sender: 'user',
      type: 'text',
      timestamp: new Date().toLocaleTimeString()
    });
    localStorage.setItem(storageKey, JSON.stringify(localMsgs));
    
    setView('home');
  };

  const handleLogout = () => {
    setUserEmail('');
    setAdminUser(null);
    localStorage.removeItem('shopify_merchant_email');
    authService.logout();
    setView('login');
  };

  const openAdminChat = (email?: string) => {
    if (email) setTargetUserEmail(email);
    setIsChatAdminView(true);
    setView('chat');
  };

  const openUserChat = () => {
    setIsChatAdminView(false);
    setView('chat');
  };

  if (!isDbReady) {
    return (
      <div className="min-h-screen bg-[#f6f6f7] flex flex-col items-center justify-center gap-6">
        <div className="relative">
          <div className="w-16 h-16 border-[5px] border-gray-200 rounded-full"></div>
          <div className="w-16 h-16 border-[5px] border-[#008060] border-t-transparent rounded-full animate-spin absolute top-0"></div>
        </div>
        <div className="font-bold text-[#202223] uppercase tracking-[0.2em] text-xs">Initializing Secure Threads...</div>
      </div>
    );
  }

  if (view === 'login') {
    return <LoginPage onLogin={handleLoginSuccess} onAdminLogin={() => setView('admin_login')} />;
  }

  if (view === 'admin_login') {
    return <AdminLoginPage onLoginSuccess={(user) => {setAdminUser(user); setView('admin_dashboard');}} onBack={() => setView('login')} />;
  }

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {view !== 'admin_dashboard' && (
        <Navbar 
          onHome={navigateToHome} 
          onLogout={handleLogout}
          userEmail={userEmail || adminUser?.email || 'guest@merchant.com'} 
          isDemo={!hasApiKey || !hasSupabaseKey}
          status={{ ai: hasApiKey, db: hasSupabaseKey }}
        />
      )}
      
      <main className="flex-1">
        {view === 'home' && (
          <div className="animate-in fade-in duration-500">
            <Hero onSearch={handleSearch} isLoading={isSearching} />
            <div className="max-w-7xl mx-auto px-4 sm:px-8" id="search-results">
              {searchResult && (
                <div className="my-12 p-8 sm:p-12 bg-white rounded-[40px] border border-gray-100 shadow-[0_20px_50px_rgba(0,128,96,0.08)] animate-in slide-in-from-bottom-8 duration-700">
                  <div className="prose prose-lg prose-green max-w-none text-[#202223] leading-relaxed ai-content">
                    <div className="whitespace-pre-wrap font-medium text-gray-700">
                      {searchResult}
                    </div>
                  </div>
                </div>
              )}
            </div>
            <section className="py-20">
              <CategoryGrid onSelectCategory={(cat) => navigateToArticle(cat.id)} />
            </section>
            <section className="bg-[#f6f6f7] py-24">
              <FAQAccordion />
            </section>
          </div>
        )}

        {view === 'article' && selectedArticleId && (
          <ArticleView articleId={selectedArticleId} onBack={navigateToHome} onSelectArticle={navigateToArticle} />
        )}

        {view === 'chat' && (
          <AdminChatPage 
            onBack={isChatAdminView ? () => setView('admin_dashboard') : navigateToHome} 
            userEmail={isChatAdminView ? targetUserEmail : userEmail} 
            isAdmin={isChatAdminView}
            isDemo={!hasSupabaseKey}
          />
        )}

        {view === 'admin_dashboard' && adminUser && (
          <AdminDashboard adminUser={adminUser} onLogout={handleLogout} onOpenChat={openAdminChat} />
        )}
      </main>

      {view === 'home' && (
        <div className="fixed bottom-10 right-10 z-50">
          <button 
            onClick={openUserChat}
            className="h-16 px-8 rounded-2xl shadow-[0_12px_40px_rgba(0,136,204,0.3)] bg-[#0088cc] text-white font-bold flex items-center gap-4 hover:scale-105 transition-all"
          >
            <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.477 2 2 6.477 2 12c0 1.891.527 3.655 1.438 5.161L2.1 21.9a.5.5 0 00.6.6l4.739-1.338A9.956 9.956 0 0012 22c5.523 0 10-4.477 10-10S17.523 2 12 2z"/></svg>
            <span>Live Help</span>
          </button>
        </div>
      )}
    </div>
  );
};

export default App;
