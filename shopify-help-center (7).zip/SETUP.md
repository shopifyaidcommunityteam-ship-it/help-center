
# Shopify Support Admin - Production Setup

This application features a robust, private admin area inspired by Shopify's internal tools.

## Current Architecture
- **Frontend**: React 19 + Tailwind CSS
- **Auth**: Simulated production-ready logic using the browser `SubtleCrypto` API for SHA-256 hashing.
- **Session**: Secure JWT-like tokens stored in `localStorage` with expiration logic.

## Production Implementation Guide

### 1. Backend Security (Node.js/Express)
To move from mock to real production, implement the following in your Node.js API:

```javascript
// Example: Hashing with Bcrypt
const bcrypt = require('bcrypt');
const hash = await bcrypt.hash(password, 10);

// Example: JWT Generation
const jwt = require('jsonwebtoken');
const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });

// Example: Secure Cookie
res.cookie('token', token, {
  httpOnly: true,
  secure: true, // Only over HTTPS
  sameSite: 'Strict'
});
```

### 2. Environment Variables
Ensure the following are set in your production environment:
- `JWT_SECRET`: A long, random string.
- `DATABASE_URL`: Your MongoDB or PostgreSQL connection string.
- `API_KEY`: Your Gemini API key for support AI.

### 3. Database Schema (Prisma/PostgreSQL Example)
```prisma
model AdminUser {
  id           String   @id @default(uuid())
  email        String   @unique
  name         String
  passwordHash String
  role         String   @default("support_admin")
  createdAt    DateTime @default(now())
}
```

## Security Checklist
- [x] Password hashing (Simulated with SHA-256)
- [x] Secure session tokens (Simulated with JWT-like expiration)
- [x] Protected routes (App.tsx state machine + authService check)
- [x] Rate limiting (Simulated in authService.ts)
- [x] Secure UI (Loading states, error handling, show/hide password)
