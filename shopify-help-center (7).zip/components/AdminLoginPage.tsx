
import React, { useState } from 'react';
import { authService } from '../services/authService';
import { AdminUser } from '../types';
import { isSupabaseConfigured } from '../lib/supabase';

interface AdminLoginPageProps {
  onLoginSuccess: (user: AdminUser) => void;
  onBack: () => void;
}

const AdminLoginPage: React.FC<AdminLoginPageProps> = ({ onLoginSuccess, onBack }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;
    
    if (!email || !password) {
      setError('Both Authorized ID and Access Key are required.');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const result = await authService.login(email, password);
      if (result.success && result.user) {
        onLoginSuccess(result.user);
      } else {
        setError(result.error || 'Identity verification failed.');
      }
    } catch (err) {
      setError('Security violation detected. Clearance denied.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f1f3f5] flex items-center justify-center px-4 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-1 bg-[#008060] opacity-20"></div>
      
      <button 
        onClick={onBack}
        className="absolute top-8 left-8 text-gray-500 hover:text-[#008060] flex items-center gap-2 text-sm font-bold transition-all"
      >
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7 7-7" />
        </svg>
        Merchant Portal
      </button>

      <div className="w-full max-w-[480px] animate-in fade-in slide-in-from-bottom-8 duration-700">
        <div className="bg-white rounded-[40px] shadow-[0_32px_64px_rgba(0,0,0,0.12)] overflow-hidden border border-white">
          <div className="p-10 sm:p-12">
            <div className="text-center mb-10">
              <div className="inline-flex items-center justify-center h-12 mb-6">
                <img 
                  src="https://logo.svgcdn.com/logos/shopify.png" 
                  className="h-10 w-auto object-contain"
                  alt="Shopify Admin"
                />
              </div>
              <h1 className="text-3xl font-black text-[#202223] tracking-tight">Support Terminal</h1>
              <p className="text-gray-400 mt-2 font-bold text-xs uppercase tracking-widest">
                Single User Access Control
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <div className="bg-red-50 border border-red-100 p-5 rounded-2xl flex items-center gap-4 animate-in shake duration-500">
                  <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center shrink-0">
                    <svg className="w-5 h-5 text-red-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <p className="text-sm text-red-900 font-bold leading-tight">{error}</p>
                </div>
              )}

              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2 px-1">Authorized ID</label>
                <input 
                  type="email" 
                  required
                  autoFocus
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-6 py-4.5 bg-gray-50 border-2 border-transparent rounded-[20px] focus:bg-white focus:border-[#008060] transition-all text-[16px] font-medium"
                  placeholder="Authorized Email Required"
                />
              </div>

              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2 px-1">Access Key</label>
                <div className="relative">
                  <input 
                    type={showPassword ? "text" : "password"} 
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-6 py-4.5 bg-gray-50 border-2 border-transparent rounded-[20px] focus:bg-white focus:border-[#008060] transition-all text-[16px] font-medium"
                    placeholder="••••••••"
                  />
                  <button 
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-[#008060] transition-colors p-2"
                  >
                    {showPassword ? (
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.882 9.882L9.882 9.882zM15.364 15.364l4.242 4.242m-4.242-4.242L21 12c-1.275 4.057-5.065 7-9.542 7-4.477 0-8.268-2.943-9.542-7a10.025 10.025 0 011.612-3.397" /></svg>
                    ) : (
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                    )}
                  </button>
                </div>
              </div>

              <button 
                type="submit"
                disabled={isLoading}
                className="w-full bg-[#202223] text-white py-5 rounded-[22px] font-black text-lg hover:bg-black transition-all shadow-[0_12px_24px_rgba(0,0,0,0.15)] active:scale-[0.97] flex items-center justify-center gap-3 disabled:opacity-70"
              >
                {isLoading ? (
                  <>
                    <svg className="animate-spin h-6 w-6 text-white" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Verifying Identity...
                  </>
                ) : (
                  'Establish Secure Connection'
                )}
              </button>
            </form>
          </div>
          
          <div className="bg-gray-50 p-6 border-t border-gray-100 flex items-center justify-between px-10">
            <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Node ID: SHP-PROD-AX7</p>
            <div className="flex items-center gap-2">
              <div className={`w-1.5 h-1.5 rounded-full animate-pulse ${isSupabaseConfigured ? 'bg-green-500' : 'bg-orange-400'}`}></div>
              <span className={`text-[10px] font-black uppercase tracking-widest ${isSupabaseConfigured ? 'text-green-600' : 'text-orange-500'}`}>
                {isSupabaseConfigured ? 'Encrypted' : 'Isolated'}
              </span>
            </div>
          </div>
        </div>

        <p className="mt-8 text-center text-gray-400 text-[11px] font-bold uppercase tracking-widest leading-loose">
          Shopify Internal Systems • Access restricted to authorized personnel only.
        </p>
      </div>
    </div>
  );
};

export default AdminLoginPage;
