
# 🛍️ Shopify Help Center Pro - Deployment Guide

Your professional help center is ready. Follow these steps to get your live link:

## 🚀 Step 1: Push to GitHub
1. Create a new repository on [GitHub](https://github.com/new).
2. Upload all the files from this project (excluding `node_modules`).
3. Commit and push your changes.

## 🔗 Step 2: Connect to Vercel
1. Go to [Vercel.com](https://vercel.com) and sign in with GitHub.
2. Click **"Add New"** -> **"Project"**.
3. Import your Shopify Help Center repository.

## 🔑 Step 3: Add Environment Variables (IMPORTANT)
Before clicking "Deploy", go to the **Environment Variables** section in Vercel and add these three:
1. `API_KEY`: Your Google Gemini API Key.
2. `VITE_SUPABASE_URL`: Found in your Supabase Project Settings -> API.
3. `VITE_SUPABASE_ANON_KEY`: Found in your Supabase Project Settings -> API.

## 🌍 Step 4: Get Your Link
1. Click **Deploy**.
2. Once finished, Vercel will give you a unique URL (e.g., `shopify-help-center.vercel.app`).
3. **That is your link!**

---

### 🛠️ Admin Access
- To access the support terminal, go to the login page.
- Enter any Gmail.
- **Tap the Star Icon (bottom right) 3 times** to open the secret Admin Login.
