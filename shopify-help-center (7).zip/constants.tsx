
import { Category, Article, FAQ } from './types';

export const CATEGORIES: Category[] = [
  {
    id: 'theme-customization',
    title: 'Customizing your theme',
    description: 'How do I customize the colors and images in my store theme?',
    icon: 'https://images.unsplash.com/photo-1633409361618-c73427e4e206?q=80&w=800&auto=format&fit=crop',
    articlesCount: 15,
  },
  {
    id: 'payments-setup',
    title: 'Setting up payments',
    description: 'Where do I get set up to accept payments from customers?',
    icon: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?q=80&w=800&auto=format&fit=crop',
    articlesCount: 12,
  },
  {
    id: 'order-fulfillment',
    title: 'Fulfilling your orders',
    description: 'How do I configure the shipping settings in my store?',
    icon: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?q=80&w=800&auto=format&fit=crop',
    articlesCount: 20,
  },
];

export const ARTICLES: Article[] = [
  {
    id: 'theme-customization',
    categoryId: 'theme-customization',
    title: 'Customizing your theme',
    content: 'Your online store theme is the foundation of your brand. In the theme editor, you can customize your theme settings to change the colors, fonts, and layout of your store. Most themes also allow you to add sections and blocks to your pages to highlight specific products or promotions. This guide covers how to use the theme editor, adjust global settings, and organize your store content for maximum impact.',
    author: 'Design Support',
    updatedAt: 'May 24, 2024',
    readTime: '6 min'
  },
  {
    id: 'payments-setup',
    categoryId: 'payments-setup',
    title: 'Setting up payments',
    content: 'To start selling, you need to set up a payment provider. Shopify Payments is the easiest way to accept payments online, but you can also choose from over 100 other payment providers. When you set up a payment provider, you can choose which payment methods you want to offer, such as credit cards, PayPal, and Apple Pay. Ensure your store currency and payout information are correctly configured to avoid transaction delays.',
    author: 'Billing Support',
    updatedAt: 'June 1, 2024',
    readTime: '4 min'
  },
  {
    id: 'order-fulfillment',
    categoryId: 'order-fulfillment',
    title: 'Fulfilling your orders',
    content: 'Fulfillment is the process of preparing and shipping an order to a customer. When a customer places an order, you can fulfill it manually or use a fulfillment service. Configuring your shipping settings correctly is vital. You can set up shipping rates, define shipping zones, and print shipping labels directly from your Shopify admin. This guide walks you through the entire fulfillment workflow from purchase to delivery.',
    author: 'Logistics Support',
    updatedAt: 'June 5, 2024',
    readTime: '7 min'
  }
];

export const FAQS: FAQ[] = [
  {
    question: "Can I use my own domain name?",
    answer: "Yes, you can use your own domain name with Shopify. If you have an existing domain name, you can connect it to Shopify from your store's admin. If you don't have a domain name yet, you can either buy one through Shopify or a third-party provider."
  },
  {
    question: "Do I need to be a designer or developer to use Shopify?",
    answer: "No, you don't need to be a designer or developer to use Shopify. Shopify's intuitive interface and customizable themes make it easy for anyone to create a professional online store without coding."
  },
  {
    question: "Which countries and currencies does Shopify support?",
    answer: "Shopify supports businesses in nearly every country in the world and allows you to sell in multiple currencies depending on your plan and payment provider."
  }
];
