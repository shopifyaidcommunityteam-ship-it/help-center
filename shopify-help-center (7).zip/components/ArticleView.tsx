
import React from 'react';
import { Article, Category } from '../types';
import { CATEGORIES, ARTICLES } from '../constants';

interface ArticleViewProps {
  articleId: string;
  onBack: () => void;
  onSelectArticle: (id: string) => void;
}

const ArticleView: React.FC<ArticleViewProps> = ({ articleId, onBack, onSelectArticle }) => {
  const article = ARTICLES.find(a => a.id === articleId) || ARTICLES[0];
  const category = CATEGORIES.find(c => c.id === article.categoryId);

  const sidebarArticles = ARTICLES.filter(a => a.categoryId === article.categoryId);

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 sm:px-8">
      {/* Breadcrumbs */}
      <nav className="flex items-center gap-3 text-xs font-bold uppercase tracking-widest text-gray-400 mb-12 overflow-hidden whitespace-nowrap">
        <button onClick={onBack} className="hover:text-[#008060] transition-colors">Support</button>
        <span>/</span>
        <span className="truncate">{category?.title}</span>
        <span>/</span>
        <span className="text-[#202223] truncate">{article.title}</span>
      </nav>

      <div className="flex flex-col lg:flex-row gap-16">
        {/* Sidebar */}
        <aside className="w-full lg:w-72 flex-shrink-0">
          <div className="sticky top-28">
            <h4 className="text-[11px] font-black text-gray-400 uppercase tracking-[0.2em] mb-6">In this category</h4>
            <div className="space-y-2 mb-12">
              {sidebarArticles.map(a => (
                <button
                  key={a.id}
                  onClick={() => onSelectArticle(a.id)}
                  className={`w-full text-left px-4 py-3 rounded-xl text-[14px] transition-all duration-200 border border-transparent ${
                    a.id === articleId 
                      ? 'bg-[#008060] text-white font-bold shadow-lg shadow-[#008060]/10' 
                      : 'text-gray-600 hover:bg-gray-100 hover:text-[#202223]'
                  }`}
                >
                  {a.title}
                </button>
              ))}
            </div>

            <div className="p-8 bg-black rounded-[32px] text-white shadow-2xl relative overflow-hidden group">
              <div className="relative z-10">
                <h5 className="text-xl font-extrabold mb-3 leading-tight">Need expert help?</h5>
                <p className="text-sm text-gray-400 mb-6 leading-relaxed">Our support specialists are available 24/7 via live chat and email.</p>
                <button className="w-full bg-[#008060] text-white py-4 rounded-2xl font-black text-sm hover:bg-[#006e52] transition-all active:scale-95 shadow-lg">
                  Contact Support
                </button>
              </div>
              <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-[#008060] rounded-full blur-[60px] opacity-20 group-hover:opacity-40 transition-opacity"></div>
            </div>
          </div>
        </aside>

        {/* Content */}
        <main className="flex-1 max-w-3xl">
          <header className="mb-12">
            <h1 className="text-[44px] sm:text-[52px] font-black text-[#202223] mb-6 tracking-tight leading-[1.1]">
              {article.title}
            </h1>
            <div className="flex flex-wrap items-center gap-6 text-[13px] font-bold text-gray-400 uppercase tracking-widest">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center border border-gray-200">
                  <svg className="w-4 h-4 text-gray-400" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" /></svg>
                </div>
                <span className="text-[#202223]">{article.author}</span>
              </div>
              <div className="flex items-center gap-2">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                <span>Updated {article.updatedAt}</span>
              </div>
              <div className="flex items-center gap-2">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>
                <span>{article.readTime} reading time</span>
              </div>
            </div>
          </header>

          <article className="prose prose-xl prose-green max-w-none text-[#202223] leading-[1.6]">
            <p className="text-2xl text-gray-500 font-medium mb-12">
              Optimize your Shopify workflow with our expert-verified guides and industry best practices for merchants.
            </p>
            <div className="space-y-8 text-[18px] text-gray-700">
              {article.content.split('\n').map((para, i) => (
                <p key={i}>{para}</p>
              ))}
            </div>
            
            <div className="my-16 p-10 bg-[#f6f6f7] rounded-[40px] border border-gray-100 relative group overflow-hidden">
              <div className="relative z-10">
                <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm mb-6 border border-gray-100">
                  <svg className="w-6 h-6 text-[#008060]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h4 className="text-xl font-black text-[#202223] mb-4">Merchant Pro Tip</h4>
                <p className="text-gray-600 leading-relaxed font-medium">
                  Merchants who use the Shopify mobile app respond to customer inquiries 2x faster. Download it today to stay connected to your business on the go.
                </p>
              </div>
              <div className="absolute top-0 right-0 w-64 h-64 bg-[#008060]/5 rounded-full blur-[80px] group-hover:bg-[#008060]/10 transition-colors"></div>
            </div>

            <div className="space-y-4">
              <h3 className="text-2xl font-bold">Related resources</h3>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4 list-none p-0">
                <li className="m-0"><a href="#" className="flex items-center p-5 rounded-2xl bg-gray-50 border border-gray-100 font-bold text-sm text-[#202223] hover:bg-white hover:border-[#008060] transition-all no-underline">Theme Editor Guide</a></li>
                <li className="m-0"><a href="#" className="flex items-center p-5 rounded-2xl bg-gray-50 border border-gray-100 font-bold text-sm text-[#202223] hover:bg-white hover:border-[#008060] transition-all no-underline">Custom Domain Setup</a></li>
              </ul>
            </div>
          </article>

          <footer className="mt-20 pt-10 border-t border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-10">
            <div>
              <p className="text-lg font-extrabold text-[#202223] mb-4">Was this article helpful?</p>
              <div className="flex gap-3">
                <button className="px-8 py-3 bg-[#008060] text-white rounded-xl font-black text-sm hover:shadow-lg transition-all active:scale-95">Yes</button>
                <button className="px-8 py-3 bg-gray-100 text-[#202223] rounded-xl font-black text-sm hover:bg-gray-200 transition-all active:scale-95">No</button>
              </div>
            </div>
            <div className="flex gap-4">
              <button className="p-3 bg-gray-50 rounded-xl text-gray-400 hover:text-[#008060] transition-all border border-gray-100">
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/></svg>
              </button>
              <button className="p-3 bg-gray-50 rounded-xl text-gray-400 hover:text-[#008060] transition-all border border-gray-100">
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 1.17.054 1.805.249 2.227.412.56.216.96.475 1.382.897.422.422.681.822.897 1.382.163.422.358 1.057.412 2.227.059 1.266.071 1.646.071 4.85s-.012 3.584-.07 4.85c-.054 1.17-.249 1.805-.412 2.227-.216.56-.475.96-.897 1.382-.422.422-.822.681-1.382.897-.422.163-1.057.358-2.227.412-1.266.059-1.646.071-4.85.071s-3.584-.012-4.85-.07c-1.17-.054-1.805-.249-2.227-.412-.56-.216-.96-.475-1.382-.897-.422-.422-.822-.681-1.382.897-.422.163-1.057.358-2.227.412-1.266.059-1.646.071-4.85.071s-3.584-.012-4.85-.07c1.17-.054 1.805-.249 2.227-.412.216-.56.475-.96.897-1.382.422-.422.822-.681 1.382-.897.422-.163 1.057-.358 2.227-.412 1.266-.059 1.646-.071 4.85-.071z"/></svg>
              </button>
            </div>
          </footer>
        </main>
      </div>
    </div>
  );
};

export default ArticleView;
