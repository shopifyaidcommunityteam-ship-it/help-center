
import React, { useState, useRef, useEffect } from 'react';
import { getSmartSupportResponse } from '../services/geminiService';
import { ChatMessage } from '../types';
import { supabase, supabaseAnonKey } from '../lib/supabase';

interface AdminChatPageProps {
  onBack: () => void;
  userEmail: string;
  isAdmin?: boolean;
  isDemo?: boolean;
}

const AdminChatPage: React.FC<AdminChatPageProps> = ({ onBack, userEmail, isAdmin = false, isDemo = false }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isRouting, setIsRouting] = useState(false);
  const [expandedImageUrl, setExpandedImageUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const isRealtimeEnabled = !!supabaseAnonKey && !isDemo;
  const LOCAL_STORAGE_KEY = `shopify_chat_${userEmail}`;
  const BUCKET_NAME = 'Images';

  // Persist messages to local storage for demo mode
  useEffect(() => {
    if (!isRealtimeEnabled && messages.length > 0) {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(messages));
    }
  }, [messages, isRealtimeEnabled, LOCAL_STORAGE_KEY]);

  // Effect to handle data loading and realtime subscriptions filtered by email
  useEffect(() => {
    if (!isRealtimeEnabled) {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) {
        setMessages(JSON.parse(saved));
      } else {
        setMessages([{
          id: 'welcome',
          text: `Welcome to Shopify Priority Support, ${userEmail.split('@')[0]}. Since this is a new session, please describe your issue; I will analyze it and immediately alert an expert to assist you.`,
          sender: 'admin',
          type: 'text',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }]);
      }
      return;
    }

    const fetchMessages = async () => {
      const { data, error } = await supabase
        .from('chat_messages')
        .select('*')
        .eq('user_email', userEmail)
        .order('created_at', { ascending: true });
      
      if (data && data.length > 0) {
        setMessages(data.map(m => ({
          id: m.id,
          text: m.text,
          imageUrl: m.image_url,
          sender: m.sender,
          type: m.type,
          timestamp: new Date(m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        })));
      } else {
        const welcomeMsg = {
          id: 'welcome-' + Date.now(),
          text: `Hello ${userEmail.split('@')[0]}, this is your dedicated support terminal. How can we help your business today?`,
          sender: 'admin' as const,
          type: 'text' as const,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setMessages([welcomeMsg]);
      }
    };
    
    fetchMessages();

    const channel = supabase.channel(`chat_${userEmail}`)
      .on('postgres_changes', { 
        event: 'INSERT', 
        schema: 'public', 
        table: 'chat_messages',
        filter: `user_email=eq.${userEmail}` 
      }, (payload) => {
        const newMessage = payload.new;
        setMessages((prev) => prev.find(m => m.id === newMessage.id) ? prev : [...prev, {
          id: newMessage.id,
          text: newMessage.text,
          imageUrl: newMessage.image_url,
          sender: newMessage.sender,
          type: newMessage.type,
          timestamp: new Date(newMessage.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }]);
      }).subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [isRealtimeEnabled, userEmail, LOCAL_STORAGE_KEY]);

  const scrollToBottom = () => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); };
  useEffect(() => { scrollToBottom(); }, [messages, isTyping]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;
    const text = inputValue;
    setInputValue('');

    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    if (isRealtimeEnabled) {
      await supabase.from('chat_messages').insert({ 
        text, 
        sender: isAdmin ? 'admin' : 'user', 
        type: 'text',
        user_email: userEmail 
      });
    } else {
      setMessages(prev => [...prev, { id: Math.random().toString(), text, sender: isAdmin ? 'admin' : 'user', type: 'text', timestamp }]);
    }

    if (!isAdmin) {
      setIsRouting(true);
      setTimeout(() => setIsTyping(true), 800);
      try {
        const response = await getSmartSupportResponse(text);
        setTimeout(async () => {
          if (isRealtimeEnabled) {
            await supabase.from('chat_messages').insert({ 
              text: response, 
              sender: 'admin', 
              type: 'text',
              user_email: userEmail 
            });
          } else {
            setMessages(prev => [...prev, { id: Math.random().toString(), text: response, sender: 'admin', type: 'text', timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
          }
          setIsTyping(false);
          setIsRouting(false);
        }, 2500);
      } catch (error) {
        setIsTyping(false);
        setIsRouting(false);
      }
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !isRealtimeEnabled) return;
    const fileName = `${userEmail}/${Math.random()}.${file.name.split('.').pop()}`;
    const { error } = await supabase.storage.from(BUCKET_NAME).upload(fileName, file);
    if (error) return;
    const { data: { publicUrl } } = supabase.storage.from(BUCKET_NAME).getPublicUrl(fileName);
    await supabase.from('chat_messages').insert({ 
      image_url: publicUrl, 
      sender: isAdmin ? 'admin' : 'user', 
      type: 'image',
      user_email: userEmail 
    });
  };

  return (
    <div className="flex-1 flex flex-col h-screen overflow-hidden bg-[#f4f6f8]">
      <div className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between shadow-sm z-20">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-full text-gray-400">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7 7-7" />
            </svg>
          </button>
          <div className="flex items-center gap-3">
            <div className="h-8 flex items-center">
              <img src="https://logo.svgcdn.com/logos/shopify.png" className="h-6 w-auto" alt="S" />
            </div>
            <div>
              <h1 className="font-bold text-[#202223] text-lg">
                {isAdmin ? `Supporting: ${userEmail}` : 'Shopify Expert Line'}
              </h1>
              <div className="flex items-center gap-1.5">
                <div className={`w-2 h-2 rounded-full ${isRouting ? 'bg-orange-500 animate-ping' : 'bg-green-500'}`}></div>
                <span className="text-[10px] text-gray-500 font-black uppercase tracking-widest">
                  {isRouting ? 'AI Triage in progress...' : 'Private Connection Secure'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        <aside className="hidden lg:flex w-80 bg-white border-r border-gray-200 flex-col p-8">
          <h2 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-8">Thread Metadata</h2>
          <div className="space-y-6">
            <div className="p-5 bg-gray-50 rounded-[20px] border border-gray-100">
              <p className="text-[10px] text-gray-400 font-black uppercase mb-2">Authenticated As</p>
              <p className="text-sm text-[#202223] font-bold break-all">{userEmail}</p>
            </div>
            <div className="p-5 bg-blue-50 rounded-[20px] border border-blue-100">
              <p className="text-[10px] text-blue-700 font-black uppercase mb-2">History State</p>
              <p className="text-xs text-blue-800 font-medium">
                {isRealtimeEnabled ? 'Legacy conversation restored from database.' : 'Thread persistent in browser local storage.'}
              </p>
            </div>
          </div>
        </aside>

        <div className="flex-1 flex flex-col relative">
          <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]">
            {messages.map((msg) => {
              const isMine = isAdmin ? msg.sender === 'admin' : msg.sender === 'user';
              return (
                <div key={msg.id} className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}>
                  <div className={`flex gap-3 max-w-[85%] sm:max-w-[70%] ${isMine ? 'flex-row-reverse' : 'flex-row'}`}>
                    <div className={`px-5 py-4 rounded-[24px] shadow-sm relative ${isMine ? 'bg-[#202223] text-white rounded-tr-none' : 'bg-white text-[#1c1d1d] rounded-tl-none border border-gray-200'}`}>
                      {msg.type === 'image' ? (
                        <img src={msg.imageUrl} className="max-h-[300px] rounded-lg cursor-pointer" onClick={() => setExpandedImageUrl(msg.imageUrl || null)} />
                      ) : (
                        <p className="text-[15px] leading-relaxed font-medium">{msg.text}</p>
                      )}
                      <div className="flex items-center gap-2 mt-2 opacity-50">
                         <span className="text-[9px] font-bold uppercase tracking-widest">{msg.timestamp}</span>
                         <span className="text-[9px] font-black">•</span>
                         <span className="text-[9px] font-bold uppercase tracking-widest">{msg.sender === 'admin' ? 'Support' : 'You'}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-white border border-gray-200 px-5 py-4 rounded-[24px] rounded-tl-none shadow-sm flex items-center gap-2">
                  <div className="flex gap-1">
                    <div className="w-1.5 h-1.5 bg-[#008060] rounded-full animate-bounce"></div>
                    <div className="w-1.5 h-1.5 bg-[#008060] rounded-full animate-bounce" style={{animationDelay:'0.2s'}}></div>
                    <div className="w-1.5 h-1.5 bg-[#008060] rounded-full animate-bounce" style={{animationDelay:'0.4s'}}></div>
                  </div>
                  <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-2">Concierge Triage...</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="bg-white border-t border-gray-200 p-6 z-10">
            <form onSubmit={handleSend} className="max-w-4xl mx-auto flex items-end gap-4">
              <input type="file" ref={fileInputRef} onChange={handleImageUpload} className="hidden" accept="image/*" />
              <button type="button" onClick={() => fileInputRef.current?.click()} className="p-4 text-gray-400 hover:text-[#008060] bg-gray-50 rounded-2xl transition-all hover:bg-gray-100">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </button>
              <textarea 
                value={inputValue} 
                onChange={(e) => setInputValue(e.target.value)} 
                placeholder="Type a message..." 
                className="flex-1 bg-white border border-gray-300 rounded-[20px] p-4 focus:ring-4 focus:ring-[#008060]/10 focus:border-[#008060] focus:outline-none resize-none font-medium text-[15px] placeholder-gray-400 transition-all shadow-sm" 
                rows={1} 
                onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSend(e as any)} 
              />
              <button type="submit" disabled={!inputValue.trim()} className={`p-4 rounded-[20px] shadow-lg transition-all active:scale-95 ${inputValue.trim() ? 'bg-[#008060] text-white hover:bg-[#006e52]' : 'bg-gray-100 text-gray-300 pointer-events-none'}`}>
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                </svg>
              </button>
            </form>
          </div>
        </div>
      </div>
      {expandedImageUrl && (
        <div className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center p-8 animate-in fade-in duration-300" onClick={() => setExpandedImageUrl(null)}>
          <img src={expandedImageUrl} className="max-w-full max-h-full rounded-2xl shadow-2xl" />
        </div>
      )}
    </div>
  );
};

export default AdminChatPage;
