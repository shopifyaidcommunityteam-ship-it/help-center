
import React from 'react';
import { CATEGORIES } from '../constants';
import { Category } from '../types';

interface CategoryGridProps {
  onSelectCategory: (cat: Category) => void;
}

const CategoryGrid: React.FC<CategoryGridProps> = ({ onSelectCategory }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8 sm:px-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {CATEGORIES.map((cat) => (
          <div 
            key={cat.id}
            onClick={() => onSelectCategory(cat)}
            className="group cursor-pointer flex flex-col bg-white border border-gray-100 rounded-2xl overflow-hidden shadow-[0_1px_4px_rgba(0,0,0,0.05)] hover:shadow-xl transition-all duration-500"
          >
            {/* Feature Image Area */}
            <div className="aspect-[16/10] overflow-hidden bg-[#f6f6f7] relative">
              <img 
                src={cat.icon} 
                alt={cat.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                loading="lazy"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1633409361618-c73427e4e206?q=80&w=800&auto=format&fit=crop';
                }}
              />
            </div>
            
            {/* Card Content */}
            <div className="p-6 sm:p-8 flex-1 flex flex-col">
              <h3 className={`text-[20px] font-bold text-[#202223] mb-3 transition-colors ${
                cat.id === 'payments-setup' ? 'underline underline-offset-[6px] decoration-[1.5px]' : 'group-hover:text-black'
              }`}>
                {cat.title}
              </h3>
              <p className="text-[#6d7175] text-[16px] leading-[1.5] font-normal">
                {cat.description}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CategoryGrid;
