
import React, { useState } from 'react';

interface NavbarProps {
  onHome: () => void;
  onLogout: () => void;
  userEmail?: string;
  isDemo?: boolean;
  status?: {
    ai: boolean;
    db: boolean;
  };
}

const Navbar: React.FC<NavbarProps> = ({ onHome, onLogout, userEmail = 'merchant@gmail.com', isDemo = false, status }) => {
  const [showDropdown, setShowDropdown] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-gray-200 px-4 py-3 sm:px-6 shadow-sm">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div 
          className="flex items-center gap-2 cursor-pointer group"
          onClick={onHome}
        >
          <div className="flex items-center gap-2.5">
            <img 
              src="https://logo.svgcdn.com/logos/shopify.png" 
              alt="Shopify" 
              className="h-7 w-auto object-contain"
            />
            <div className="flex items-center gap-2">
              <span className="text-gray-300 text-xl font-light">|</span>
              <span className="text-[17px] font-medium text-[#6d7175]">Help Center</span>
            </div>
            {isDemo && (
              <div className="flex items-center gap-1 ml-4">
                <span className="px-2 py-0.5 bg-orange-100 text-orange-700 text-[10px] font-black uppercase tracking-widest rounded-md border border-orange-200">
                  Preview Mode
                </span>
                {status && (
                  <div className="flex items-center gap-1.5 px-2 py-0.5 bg-gray-50 rounded-md border border-gray-100">
                    <div className={`w-1.5 h-1.5 rounded-full ${status.ai ? 'bg-green-500' : 'bg-red-400'}`} title={status.ai ? "AI Active" : "AI Missing"}></div>
                    <div className={`w-1.5 h-1.5 rounded-full ${status.db ? 'bg-green-500' : 'bg-red-400'}`} title={status.db ? "Database Active" : "Database Missing"}></div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-4 relative">
          <div 
            onClick={() => setShowDropdown(!showDropdown)}
            className="flex items-center gap-3 px-3 py-1.5 rounded-full hover:bg-gray-100 transition-colors cursor-pointer border border-transparent hover:border-gray-200"
          >
            <span className="hidden sm:block text-sm font-medium text-[#202223]">
              {userEmail}
            </span>
            <div className="w-8 h-8 rounded-full bg-[#008060] flex items-center justify-center text-white text-xs font-bold shadow-sm">
              {userEmail.charAt(0).toUpperCase()}
            </div>
          </div>

          {showDropdown && (
            <>
              <div className="fixed inset-0 z-0" onClick={() => setShowDropdown(false)}></div>
              <div className="absolute right-0 top-full mt-2 w-48 bg-white border border-gray-200 rounded-2xl shadow-xl z-10 py-2 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
                <div className="px-4 py-3 border-b border-gray-50">
                  <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-1">Signed in as</p>
                  <p className="text-xs font-bold text-[#202223] truncate">{userEmail}</p>
                </div>
                <button 
                  onClick={() => {
                    setShowDropdown(false);
                    onLogout();
                  }}
                  className="w-full text-left px-4 py-3 text-sm font-bold text-red-600 hover:bg-red-50 transition-colors flex items-center gap-3"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.3} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                  </svg>
                  Sign Out
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
