
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { AdminUser } from '../types';

// Hardened admin terminal access credentials
const AUTHORIZED_ADMIN_EMAIL = 'adesinahephzibah77@gmail.com';
const REQUIRED_PASSWORD = 'hephzibah@(79)';

export const authService = {
  /**
   * Performs authentication with strict email and password enforcement for the terminal.
   */
  async login(emailInput: string, passwordInput: string): Promise<{ success: boolean; user?: AdminUser; error?: string }> {
    const email = emailInput.trim().toLowerCase();
    const password = passwordInput;

    // 1. STRICT TERMINAL ACCESS CONTROL
    if (email !== AUTHORIZED_ADMIN_EMAIL) {
      return { 
        success: false, 
        error: 'Terminal Access Denied: This ID does not have clearance for support operations.' 
      };
    }

    if (password !== REQUIRED_PASSWORD) {
      return { 
        success: false, 
        error: 'Invalid Terminal Access Key. Security lockout in progress.' 
      };
    }

    // 2. DEMO MODE BYPASS: If no Supabase config, allow demo login after passing strict checks
    if (!isSupabaseConfigured) {
      console.warn("Supabase not configured. Using Demo Mode login.");
      return {
        success: true,
        user: {
          id: 'authorized-admin-demo',
          email: AUTHORIZED_ADMIN_EMAIL,
          name: 'Hephzibah',
          role: 'super_admin'
        }
      };
    }

    try {
      // In production, we sign in to the database with the authorized credentials
      const { data, error } = await supabase.auth.signInWithPassword({
        email: AUTHORIZED_ADMIN_EMAIL,
        password: REQUIRED_PASSWORD,
      });

      // 3. DATABASE FALLBACK: Handle cases where DB is not yet synced with this specific user
      if (error) {
        if (error.status === 400 || error.status === 401) {
          return {
            success: true,
            user: {
              id: 'authorized-admin-fallback',
              email: AUTHORIZED_ADMIN_EMAIL,
              name: 'Hephzibah',
              role: 'super_admin'
            }
          };
        }
        throw error;
      }

      if (data.user) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', data.user.id)
          .single();

        return {
          success: true,
          user: {
            id: data.user.id,
            email: data.user.email || AUTHORIZED_ADMIN_EMAIL,
            name: profile?.name || 'Hephzibah',
            role: profile?.role || 'super_admin'
          }
        };
      }

      return { success: false, error: 'Identity verification failed.' };
    } catch (err: any) {
      console.error("Auth error:", err);
      return { 
        success: false, 
        error: 'Critical terminal error during verification.' 
      };
    }
  },

  async logout() {
    if (isSupabaseConfigured) {
      await supabase.auth.signOut().catch(() => {});
    }
  },

  async getCurrentUser(): Promise<AdminUser | null> {
    if (!isSupabaseConfigured) return null;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user || session.user.email !== AUTHORIZED_ADMIN_EMAIL) return null;
      
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', session.user.id)
        .single();

      return {
        id: session.user.id,
        email: session.user.email || AUTHORIZED_ADMIN_EMAIL,
        name: profile?.name || 'Hephzibah',
        role: profile?.role || 'super_admin'
      };
    } catch (e) {
      return null;
    }
  }
};
