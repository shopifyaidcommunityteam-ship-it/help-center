
import React, { useState } from 'react';
import { FAQS } from '../constants';

const FAQAccordion: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <div className="max-w-3xl mx-auto px-4 py-16">
      <h2 className="text-2xl font-bold text-[#202223] mb-8 text-center">Frequently Asked Questions</h2>
      <div className="space-y-4">
        {FAQS.map((faq, index) => (
          <div 
            key={index} 
            className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm"
          >
            <button
              onClick={() => setOpenIndex(openIndex === index ? null : index)}
              className="w-full flex items-center justify-between p-6 text-left focus:outline-none group"
            >
              <span className="text-lg font-semibold text-[#202223] group-hover:text-[#008060] transition-colors">
                {faq.question}
              </span>
              <svg 
                className={`w-6 h-6 transform transition-transform text-gray-400 ${openIndex === index ? 'rotate-180' : ''}`} 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>
            <div 
              className={`transition-all duration-300 ease-in-out ${openIndex === index ? 'max-h-[500px] opacity-100' : 'max-h-0 opacity-0'} overflow-hidden`}
            >
              <div className="p-6 pt-0 text-[#6d7175] leading-relaxed border-t border-gray-50">
                {faq.answer}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FAQAccordion;
