
export interface Category {
  id: string;
  title: string;
  description: string;
  icon: string;
  articlesCount: number;
}

export interface Article {
  id: string;
  categoryId: string;
  title: string;
  content: string;
  author: string;
  updatedAt: string;
  readTime: string;
}

export interface FAQ {
  question: string;
  answer: string;
}

export interface ChatMessage {
  id: string;
  text?: string;
  imageUrl?: string;
  sender: 'admin' | 'user';
  timestamp: string;
  type: 'text' | 'image' | 'link';
}

export interface AdminUser {
  id: string;
  email: string;
  name: string;
  role: 'super_admin' | 'support_admin';
}

export type ViewState = 'login' | 'home' | 'category' | 'article' | 'chat' | 'admin_login' | 'admin_dashboard';
