
import { GoogleGenAI } from "@google/genai";

/**
 * Handles communication with the Gemini API to provide smart concierge responses.
 * Refactored to use stable aliases and explicit content structures to avoid RPC proxy errors.
 */
export async function getSmartSupportResponse(query: string) {
  const apiKey = process.env.API_KEY;
  
  if (!apiKey) {
    console.warn("Gemini API Key missing. Service entering fallback mode.");
    return "Our automated concierge is currently offline. Please wait a moment while I alert a human specialist to your thread.";
  }

  // Initializing with the mandatory named parameter
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  try {
    const response = await ai.models.generateContent({
      // Use 'gemini-flash-latest' for better stability with the Alkali proxy
      model: 'gemini-flash-latest',
      // Explicit Content[] structure to satisfy RPC requirements
      contents: [
        {
          role: 'user',
          parts: [{ text: query }]
        }
      ],
      config: {
        systemInstruction: `You are the Shopify Support Concierge. 
        Your ONLY job is to:
        1. Empathize with the merchant's issue.
        2. Acknowledge exactly what they are experiencing.
        3. Explicitly tell them to stay on the line because you are notifying a human support specialist.
        4. Do NOT give any technical advice or instructions.
        5. Keep response under 2 sentences.`,
        temperature: 0.7,
        topP: 0.95,
        topK: 40
      },
    });

    // Accessing .text property directly as per coding guidelines
    const text = response.text;
    
    if (!text) {
      throw new Error("Empty response from AI model");
    }

    return text;
  } catch (error: any) {
    // Detailed logging for debugging ProxyUnaryCall failures
    console.error("Gemini Service Error:", {
      message: error.message,
      status: error.status,
      code: error.code
    });

    // Graceful fallback for the merchant UI
    return "I've acknowledged your request regarding this issue. I'm signaling our priority support team now—please stay connected.";
  }
}
