
import React, { useState } from 'react';

interface HeroProps {
  onSearch: (query: string) => void;
  isLoading: boolean;
}

const TRENDING = [
  "Install a theme",
  "Shopify Payments",
  "Custom domains",
  "Refund an order"
];

const Hero: React.FC<HeroProps> = ({ onSearch, isLoading }) => {
  const [query, setQuery] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim() && !isLoading) {
      onSearch(query);
    }
  };

  return (
    <div className="bg-white pt-16 pb-12 sm:pt-24 border-b border-gray-50">
      <div className="max-w-4xl mx-auto px-4 text-center">
        <h1 className="text-[40px] sm:text-[56px] font-extrabold text-[#202223] mb-8 tracking-tight leading-tight">
          How can we help you?
        </h1>
        
        <form onSubmit={handleSubmit} className="relative max-w-[720px] mx-auto mb-8">
          <div className="relative group">
            <div className="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-[#008060] border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <svg className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              )}
            </div>
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search for articles, guides, and more..."
              disabled={isLoading}
              className="block w-full pl-14 pr-12 py-5 border border-gray-200 rounded-2xl bg-white focus:outline-none focus:ring-4 focus:ring-[#008060]/5 focus:border-[#008060] transition-all text-[18px] shadow-[0_4px_12px_rgba(0,0,0,0.03)] placeholder-gray-400"
            />
            {query && !isLoading && (
              <button 
                type="button" 
                onClick={() => setQuery('')}
                className="absolute inset-y-0 right-4 flex items-center text-gray-400 hover:text-gray-600"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            )}
          </div>
        </form>

        <div className="flex flex-wrap items-center justify-center gap-3">
          <span className="text-[13px] font-semibold text-gray-400 uppercase tracking-wider mr-2">Trending:</span>
          {TRENDING.map((item) => (
            <button
              key={item}
              onClick={() => {
                setQuery(item);
                onSearch(item);
              }}
              className="px-4 py-1.5 rounded-full bg-gray-100 text-[#202223] text-sm font-medium hover:bg-[#008060] hover:text-white transition-all border border-transparent active:scale-95"
            >
              {item}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Hero;
