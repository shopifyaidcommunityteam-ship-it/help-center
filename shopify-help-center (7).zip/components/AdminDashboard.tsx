
import React, { useState, useEffect, useMemo } from 'react';
import { AdminUser } from '../types';
import { supabase, isSupabaseConfigured } from '../lib/supabase';

interface AdminDashboardProps {
  adminUser: AdminUser;
  onLogout: () => void;
  onOpenChat: (email?: string) => void;
}

interface Ticket {
  email: string;
  lastMessage: string;
  lastTimestamp: string;
  fullTimestamp: string;
  priority: 'High' | 'Normal';
  status: 'Action Required' | 'Waiting' | 'New Entry';
  unreadCount: number;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ adminUser, onLogout, onOpenChat }) => {
  const [activeTab, setActiveTab] = useState('tickets');
  const [dbStatus, setDbStatus] = useState<'checking' | 'connected' | 'demo' | 'error'>('checking');
  const [messages, setMessages] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  const fetchMessages = async () => {
    // 1. Check if we have a real database connection
    if (!isSupabaseConfigured) {
      setDbStatus('demo');
      // In Demo Mode, try to collect "session pings" from local storage
      // This allows the Admin to see merchants who logged in on the same browser
      const demoMessages: any[] = [];
      
      // We look for a global 'demo_logs' or scan local keys
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key?.startsWith('shopify_chat_')) {
          const stored = JSON.parse(localStorage.getItem(key) || '[]');
          demoMessages.push(...stored.map((m: any) => ({
            ...m,
            user_email: key.replace('shopify_chat_', ''),
            created_at: new Date().toISOString() // Fallback timestamp
          })));
        }
      }
      setMessages(demoMessages);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('chat_messages')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setMessages(data || []);
      setDbStatus('connected');
    } catch (err) {
      console.error("Dashboard Fetch Error:", err);
      setDbStatus('error');
    }
  };

  useEffect(() => {
    fetchMessages();

    if (isSupabaseConfigured) {
      const channel = supabase.channel('global_dashboard_updates')
        .on('postgres_changes', { 
          event: '*', 
          schema: 'public', 
          table: 'chat_messages' 
        }, () => {
          fetchMessages();
        }).subscribe();

      return () => { supabase.removeChannel(channel); };
    } else {
      // In Demo Mode, poll local storage occasionally to simulate real-time
      const interval = setInterval(fetchMessages, 3000);
      return () => clearInterval(interval);
    }
  }, []);

  const tickets = useMemo(() => {
    const threadMap = new Map<string, Ticket>();
    
    // Sort messages so we get the latest per user
    const sortedMessages = [...messages].sort((a, b) => 
      new Date(b.created_at || b.timestamp).getTime() - new Date(a.created_at || a.timestamp).getTime()
    );

    sortedMessages.forEach(msg => {
      const email = msg.user_email || 'unknown@merchant.com';
      if (!threadMap.has(email)) {
        const isSessionInit = msg.text?.includes('--- Merchant Session Initialized ---');
        threadMap.set(email, {
          email,
          lastMessage: isSessionInit ? 'Authenticated & Browsing' : (msg.text || 'No content'),
          lastTimestamp: new Date(msg.created_at || msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          fullTimestamp: new Date(msg.created_at || msg.timestamp).toLocaleString(),
          priority: (msg.text?.length > 150 || msg.type === 'image') ? 'High' : 'Normal',
          status: isSessionInit ? 'New Entry' : (msg.sender === 'user' ? 'Action Required' : 'Waiting'),
          unreadCount: 0 
        });
      }
    });

    return Array.from(threadMap.values());
  }, [messages]);

  const filteredTickets = useMemo(() => {
    return tickets.filter(t => 
      t.email.toLowerCase().includes(searchQuery.toLowerCase()) || 
      t.lastMessage.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [tickets, searchQuery]);

  const stats = useMemo(() => ({
    totalMerchants: tickets.length,
    needsAction: tickets.filter(t => t.status === 'Action Required').length,
    newLogins: tickets.filter(t => t.status === 'New Entry').length
  }), [tickets]);

  return (
    <div className="flex h-screen bg-[#f0f2f5] overflow-hidden font-sans">
      <aside className="w-72 bg-[#202223] text-white flex flex-col hidden lg:flex shadow-2xl z-30">
        <div className="p-8">
          <div className="flex items-center gap-3 mb-10" onClick={() => window.location.reload()}>
            <img src="https://logo.svgcdn.com/logos/shopify.png" className="w-8 h-8 object-contain cursor-pointer" alt="Shopify" />
            <span className="text-xl font-black tracking-tighter uppercase cursor-pointer">Support Terminal</span>
          </div>
          <nav className="space-y-2">
            {[
              { id: 'tickets', label: 'Priority Inbox', icon: 'M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z' },
              { id: 'merchants', label: 'Merchant Directory', icon: 'M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z' },
            ].map(item => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl text-sm font-bold transition-all ${
                  activeTab === item.id ? 'bg-[#008060] text-white shadow-lg' : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
                </svg>
                {item.label}
              </button>
            ))}
          </nav>
        </div>
        <div className="mt-auto p-8">
          <div className="bg-white/5 rounded-3xl p-6 border border-white/10">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 rounded-full bg-[#008060] flex items-center justify-center text-[10px] font-black">{adminUser.name.charAt(0).toUpperCase()}</div>
              <p className="font-bold truncate text-sm">{adminUser.name}</p>
            </div>
            <button onClick={onLogout} className="w-full bg-red-500/10 hover:bg-red-500/20 py-2.5 rounded-xl text-xs font-bold text-red-400 transition-all border border-red-500/20">Sign Out</button>
          </div>
        </div>
      </aside>

      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-white border-b border-gray-200 px-8 py-5 flex items-center justify-between shadow-sm z-20">
          <div className="flex items-center gap-8">
            <h2 className="text-xl font-black text-[#202223] uppercase tracking-tighter">Support Pipeline</h2>
            <div className="relative w-80">
              <input 
                type="text" 
                placeholder="Search merchants..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-gray-100 border-none rounded-xl pl-10 pr-4 py-2 text-sm focus:ring-2 focus:ring-[#008060]/20 focus:bg-white transition-all"
              />
              <svg className="w-4 h-4 absolute left-3 top-2.5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
          </div>
          <div className="flex items-center gap-4">
            {dbStatus === 'demo' ? (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-50 rounded-full border border-blue-100">
                <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></div>
                <span className="text-[10px] font-black text-blue-700 uppercase tracking-widest">Demo Sandbox Active</span>
              </div>
            ) : (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-green-50 rounded-full border border-green-100">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                <span className="text-[10px] font-black text-green-700 uppercase tracking-widest">Production Sync Active</span>
              </div>
            )}
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-[32px] border border-gray-200 shadow-sm relative overflow-hidden group">
              <p className="text-[11px] font-black text-gray-400 uppercase tracking-widest mb-1">Total Merchants</p>
              <p className="text-3xl font-black text-[#202223]">{stats.totalMerchants}</p>
            </div>
            <div className="bg-white p-6 rounded-[32px] border border-gray-200 shadow-sm relative overflow-hidden">
              <p className="text-[11px] font-black text-gray-400 uppercase tracking-widest mb-1">Attention Required</p>
              <p className="text-3xl font-black text-orange-600">{stats.needsAction}</p>
            </div>
            <div className="bg-white p-6 rounded-[32px] border border-gray-200 shadow-sm relative overflow-hidden">
              <p className="text-[11px] font-black text-gray-400 uppercase tracking-widest mb-1">Fresh Sessions</p>
              <p className="text-3xl font-black text-[#008060]">{stats.newLogins}</p>
            </div>
          </div>

          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="bg-white rounded-[40px] border border-gray-100 shadow-xl overflow-hidden">
              <div className="px-10 py-6 border-b border-gray-100 flex items-center justify-between bg-gray-50/20">
                <h3 className="text-sm font-black uppercase tracking-widest text-gray-400">Activity Registry</h3>
              </div>
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-gray-50/50 text-[11px] font-black text-gray-400 uppercase tracking-widest border-b border-gray-100">
                    <th className="px-10 py-6">Merchant Identity</th>
                    <th className="px-10 py-6">Latest Event</th>
                    <th className="px-10 py-6">Status</th>
                    <th className="px-10 py-6 text-right">Access Thread</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {filteredTickets.map((ticket, i) => (
                    <tr key={ticket.email} className="group hover:bg-gray-50/80 transition-all cursor-pointer" onClick={() => onOpenChat(ticket.email)}>
                      <td className="px-10 py-8">
                        <div className="flex items-center gap-5">
                          <div className="w-12 h-12 rounded-[20px] bg-[#202223] flex items-center justify-center font-bold text-white text-lg shadow-lg">
                            {ticket.email.charAt(0).toUpperCase()}
                          </div>
                          <p className="font-black text-[#202223] text-sm truncate max-w-[220px]">{ticket.email}</p>
                        </div>
                      </td>
                      <td className="px-10 py-8">
                        <p className="text-xs text-gray-600 truncate font-medium italic">"{ticket.lastMessage}"</p>
                      </td>
                      <td className="px-10 py-8">
                        <span className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest border ${
                          ticket.status === 'Action Required' ? 'bg-orange-50 text-orange-700 border-orange-200' : 
                          ticket.status === 'New Entry' ? 'bg-green-50 text-green-700 border-green-200' : 'bg-blue-50 text-blue-700 border-blue-200'
                        }`}>
                          {ticket.status}
                        </span>
                      </td>
                      <td className="px-10 py-8 text-right">
                        <button className="bg-[#202223] text-white px-6 py-3 rounded-[18px] font-black text-xs hover:bg-[#008060] transition-all whitespace-nowrap">
                          Continue Chat
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminDashboard;
